<?php
/*
Plugin Name: Saudi Riyal Symbol | رمز الريال السعودي
Plugin URI: https://plugins.arib.sa/saudiriyalsymbol
Description: ‎إصدار مجاني بفترة تجريبية ٩٠ يومًا تبدأ من لحظة تفعيل كود الترخيص. قبل إدخال الكود لا تعمل أي من خصائص الإضافة.
Version: 4.1.0
Author: Arib IT
Author URI: https://arib.sa
License: GPLv2 or later
Text Domain: saudi-riyal-symbol
*/
if (!defined('ABSPATH')) { exit; }

define('SRS_VERSION', '4.1.0');
define('SRS_OPTION_TRIAL_START', 'srs_trial_start');
define('SRS_OPTION_LICENSE_STATUS', 'srs_license_status');
define('SRS_OPTION_LICENSE_CODE', 'srs_license_code');
define('SRS_OPTION_CLIENT_NAME', 'srs_client_name');
define('SRS_TRIAL_DAYS', 90);
define('SRS_PURCHASE_URL', 'https://plugins.arib.sa/saudiriyalsymbol');

/* ============ INCLUDE LICENSEBOX HELPER ============ */
require_once plugin_dir_path(__FILE__) . 'licensebox-helper.php';
$SRS_LBX = new LicenseBoxExternalAPI();

/* ============ HELPERS ============ */
function srs_trial_remaining_days() {
    $start = (int) get_option(SRS_OPTION_TRIAL_START, 0);
    if (!$start) return 0;
    $expiry = $start + (SRS_TRIAL_DAYS * DAY_IN_SECONDS);
    return $expiry > time() ? ceil(($expiry - time()) / DAY_IN_SECONDS) : 0;
}
function srs_is_authorised() {
    return get_option(SRS_OPTION_LICENSE_STATUS, 'invalid') === 'valid' && srs_trial_remaining_days() > 0;
}

/* ============ NOTICES ============ */
add_action('admin_notices', function () {
    $status = get_option(SRS_OPTION_LICENSE_STATUS, 'invalid');
    if ($status !== 'valid') {
        echo '<div class="notice notice-warning is-dismissible"><p>'
            . __('Saudi Riyal Symbol: Please activate your free 90‑day licence.', 'saudi-riyal-symbol')
            . ' <a href="' . esc_url(admin_url('admin.php?page=srs-license')) . '">' . __('Activate Now', 'saudi-riyal-symbol') . '</a></p></div>';
        return;
    }
    $days = srs_trial_remaining_days();
    if ($days > 0) {
        echo '<div class="notice notice-success is-dismissible"><p>'
             . sprintf(__('Saudi Riyal Symbol: Trial remaining: %s day(s).', 'saudi-riyal-symbol'), $days)
             . ' · <a href="'. esc_url(SRS_PURCHASE_URL) .'" target="_blank">' . __('Purchase Full Licence', 'saudi-riyal-symbol') . '</a></p></div>';
    } else {
        echo '<div class="notice notice-error"><p>'
             . __('Saudi Riyal Symbol: Trial expired — plugin disabled.', 'saudi-riyal-symbol')
             . ' <a href="'. esc_url(SRS_PURCHASE_URL) .'" target="_blank">' . __('Purchase Full Licence', 'saudi-riyal-symbol') . '</a></p></div>';
    }
});

/* ============ ADMIN MENU ============ */
add_action('admin_menu', function () {
    add_menu_page('SRS License', 'SRS License', 'manage_options', 'srs-license', 'srs_render_license_page', 'dashicons-admin-network', 56);
});

/* ============ LICENSE FORM HANDLERS ============ */
add_action('admin_post_srs_save_license', function () use ($SRS_LBX) {
    if (!current_user_can('manage_options') || !check_admin_referer('srs_save_license')) wp_die('unauthorized');
    $code = sanitize_text_field($_POST['license_code']??'');
    $client = sanitize_text_field($_POST['client_name']??'');
    $res = $SRS_LBX->activate_license($code,$client,true);
    if($res['status']) {
        update_option(SRS_OPTION_LICENSE_STATUS,'valid');
        update_option(SRS_OPTION_LICENSE_CODE,$code);
        update_option(SRS_OPTION_CLIENT_NAME,$client);
        if(!get_option(SRS_OPTION_TRIAL_START)) update_option(SRS_OPTION_TRIAL_START,time());
        $msg='ok';
    } else {
        update_option(SRS_OPTION_LICENSE_STATUS,'invalid');
        $msg='fail';
    }
    wp_redirect(admin_url('admin.php?page=srs-license&msg='.$msg));exit;
});
add_action('admin_post_srs_deactivate_license', function () use ($SRS_LBX) {
    if (!current_user_can('manage_options') || !check_admin_referer('srs_save_license')) wp_die('unauthorized');
    $code=get_option(SRS_OPTION_LICENSE_CODE);$client=get_option(SRS_OPTION_CLIENT_NAME);
    $SRS_LBX->deactivate_license($code,$client);
    delete_option(SRS_OPTION_LICENSE_STATUS);delete_option(SRS_OPTION_LICENSE_CODE);delete_option(SRS_OPTION_CLIENT_NAME);delete_option(SRS_OPTION_TRIAL_START);
    wp_redirect(admin_url('admin.php?page=srs-license'));exit;
});

/* ============ RENDER LICENSE PAGE ============ */
function srs_render_license_page() {
    $status = get_option(SRS_OPTION_LICENSE_STATUS,'invalid');
    $days = srs_trial_remaining_days();
    echo '<div class="wrap"><h1>Saudi Riyal Symbol – Licence</h1>';
    if($status==='valid' && $days>0){
        echo '<p><strong>Status:</strong> Active | <strong>Days left:</strong> '.$days.'</p>';
        echo '<form method="post" action="'.admin_url('admin-post.php').'">';
        wp_nonce_field('srs_save_license');
        echo '<input type="hidden" name="action" value="srs_deactivate_license" />';
        submit_button('Deactivate Licence','secondary');
        echo '</form><hr><a class="button" href="'.esc_url(SRS_PURCHASE_URL).'" target="_blank">Purchase Full Licence</a>';
    } else {
        echo '<form method="post" action="'.admin_url('admin-post.php').'">';
        wp_nonce_field('srs_save_license');
        echo '<table class="form-table"><tr><th><label for="license_code">Licence Code</label></th><td><input id="license_code" name="license_code" type="text" class="regular-text" required></td></tr>';
        echo '<tr><th><label for="client_name">Client Name</label></th><td><input id="client_name" name="client_name" type="text" class="regular-text" required></td></tr></table>';
        echo '<input type="hidden" name="action" value="srs_save_license" />';
        submit_button('Activate Licence','primary');
        echo '</form>';
    }
    echo '</div>';
}

/* ============ PLUGIN FUNCTIONALITY (only when authorised) ============ */
if (srs_is_authorised()) {
    add_action('wp_enqueue_scripts', function(){
        wp_enqueue_style('saudi-riyal-font',plugins_url('assets/css/saudi-riyal.css',__FILE__),[], '1.2');
    },20);
    add_action('admin_enqueue_scripts', function(){
        wp_enqueue_style('saudi-riyal-font',plugins_url('assets/css/saudi-riyal.css',__FILE__),[], '1.2');
    },20);
    add_filter('woocommerce_currency_symbol', function($symbol,$currency){
        return $currency==='SAR' ? '<span class="srs-glyph" aria-label="SAR">&#xE900;</span>' : $symbol;
    },10,2);
    add_filter('woocommerce_price_format', fn($f)=>is_rtl()?'%1$s&nbsp;%2$s':'%2$s&nbsp;%1$s');
}
?>