# Saudi Riyal Symbol | رمز الريال السعودي

![PHP](https://img.shields.io/badge/PHP-7.4%2B-blue) ![License](https://img.shields.io/badge/license-GPLv2-blue)

A lightweight WordPress / WooCommerce plugin that replaces the SAR currency code with the official **Saudi Riyal** glyph from the *Saudi_Riyal* font.  
يدعم هذا الملحق استبدال رمز عملة الريال السعودي (SAR) في ووكومرس بالرمز الجديد باستخدام خط *Saudi_Riyal* المضمّن، مع توافق كامل للتصاميم من اليمين إلى اليسار (RTL) أو من اليسار إلى اليمين (LTR).

---

## Features | الميزات

- **Auto‑detect RTL/LTR** — السعر ثم الرمز أو العكس تلقائيًا  
- **Bundled font** — no external calls  
- **Pure PHP + CSS** — zero JavaScript  
- **Easy colour override** via CSS variable `--riyals-color`  
- **GPL‑v2** — open‑source & free

---

## Installation | التثبيت

1. Download the ZIP or clone the repository inside your `wp-content/plugins` directory:
   ```bash
   git clone https://github.com/YOUR_USERNAME/saudi-riyal-symbol.git
   ```
2. Activate **Saudi Riyal Symbol | رمز الريال السعودي** from the WordPress admin.
3. Clear any cache. Prices will now display, e.g.:

   *RTL:* `𞸀 299.00`   •   *LTR:* `299.00 𞸀`

---

## Customisation | التخصيص

```css
:root {
  --riyals-color: #1a1a1a; /* change glyph colour */
}
```

---

## Contributing | المساهمة

Pull requests are welcome. For major changes, please open an issue first to discuss what you would like to change.

---

## License | الرخصة

Distributed under the **GNU General Public License v2.0 or later**. See `LICENSE` for more information.
