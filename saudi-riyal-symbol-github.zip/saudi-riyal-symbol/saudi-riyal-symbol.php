<?php
/*
Plugin Name: Saudi Riyal Symbol | رمز الريال السعودي
Plugin URI: https://arib.sa
Description: Replaces WooCommerce SAR currency symbol with the Saudi Riyal glyph (\uE900) from the bundled Saudi_Riyal font — يدعم استبدال رمز عملة الريال السعودي (SAR) في ووكومرس بالرمز الجديد باستخدام خط Saudi_Riyal، مع توافق كامل لواجهات RTL/LTR.
Version: 3.5
Author: Arib IT
Author URI: https://arib.sa
License: GPLv2 or later
Text Domain: saudi-riyal-symbol
*/

if (!defined('ABSPATH')) { exit; }

function srs_enqueue_font(){
    wp_enqueue_style(
        'srs-saudi-font',
        plugins_url('assets/css/saudi-riyal.css', __FILE__),
        array(),
        '1.2'
    );
}
add_action('wp_enqueue_scripts','srs_enqueue_font',20);
add_action('admin_enqueue_scripts','srs_enqueue_font',20);

function srs_currency_symbol($symbol,$currency){
    if($currency==='SAR'){
        return '<span class="srs-glyph" aria-label="SAR">&#xE900;</span>';
    }
    return $symbol;
}
add_filter('woocommerce_currency_symbol','srs_currency_symbol',10,2);

add_filter('woocommerce_price_format', fn($f)=> is_rtl() ? '%1$s&nbsp;%2$s' : '%2$s&nbsp;%1$s');
?>
